# -------------------------------------------------#
# Title: Working with exception handling and object serialization
# Dev:   PZilly
# Date:  Dec 1, 2018
# ChangeLog: (Who, When, What)
#   PZilly, 12/2/2018, Added code to complete assignment 7
# -------------------------------------------------#


# Global variable section

import pickle
objFile = None

# Processing section

def GetCustomerData(File): # This function gets the Customer name and ID and adds the values to a dictionary
    while True:
        CustomerName = str(input("Enter a Name: "))
        if CustomerName.isalpha():
            break
        print("You did not enter a name")
    try: # The try / except block returns an error if the user does not enter an integer
        CustomerId = int(input("Enter an Id number: "))
    except ValueError:
        print("You did not enter a number")
    DictCustomer = {CustomerName, CustomerId} # Add the data to a dictionary
    print(DictCustomer)
    pickle.dump(DictCustomer, File) # Write a pickled representation of data to the file.

def ReadData(): # This function reads the data from the file
    try: # try / except block returns an error if unable to open the file.
        objFile = open("Customers.dat", "rb")
    except IOError as e:
        print("Unable to open file", objFile, e)
    objFileData = pickle.load(objFile)
    print(objFileData)

# I/O section

objFile = open("Customers.dat", "ab") # Open the Customer.dat file
GetCustomerData(objFile)
ReadData()
objFile.close() # Close the file object