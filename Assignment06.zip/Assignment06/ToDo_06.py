# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   PZilly
# Date:  Nov 24, 2018
# ChangeLog: (Who, When, What)
#   PZilly, 11/25/2018, Added code to complete assignment 6
# -------------------------------------------------#

# Global variable section
objFileName = "ToDo.txt"
strData = ""
dicRow = {}
lstTable = []


class ToDo():
    # Define the functions in the ToDo program using a class

    @staticmethod
    def LoadFile():
        # This function loads the ToDo.txt file from the source location
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    @staticmethod
    def DisplayList():
        # The DisplayList function presents the current list of tasks to the user
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print (row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod
    def SaveFile():
        # This function saves the current tasks to the source file and closes the file
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()

    @staticmethod
    def Main():
        '''
        The Main function is the main program loop that performs the following:
        :Presents the menu to the user
        :Calls the DisplayList, SaveFile functions
        :User can insert or delete data
         '''
        while (True):
            print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            print()  # adding a new line

            # Step 3
            # Show the current items in the table
            if (strChoice.strip() == '1'):
                x.DisplayList()

            # Step 4
            # Add a new item to the list/Table
            elif (strChoice.strip() == '2'):
                strTask = str(input("What is the task? - ")).strip()
                strPriority = str(input("What is the priority? [high|low] - ")).strip()
                dicRow = {"Task": strTask, "Priority": strPriority}
                lstTable.append(dicRow)
                print("Current Data in table:")
                for dicRow in lstTable:
                    print(dicRow)

                # 4a Show the current items in the table
                x.DisplayList()
                continue  # to show the menu

            # Step 5
            # Remove a new item to the list/Table
            elif (strChoice == '3'):
                # 5a-Allow user to indicate which row to delete
                strKeyToRemove = input("Which TASK would you like removed? - ")
                blnItemRemoved = False  # Creating a boolean Flag
                intRowNumber = 0
                while (intRowNumber < len(lstTable)):
                    if (strKeyToRemove == str(
                            list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                        del lstTable[intRowNumber]
                        blnItemRemoved = True
                    # end if
                    intRowNumber += 1
                # end for loop
                # 5b-Update user on the status
                if (blnItemRemoved == True):
                    print("The task was removed.")
                else:
                    print("I'm sorry, but I could not find that task.")

                # 5c Show the current items in the table
                x.DisplayList()
                continue  # to show the menu

            # Step 6
            # Save tasks to the ToDo.txt file
            elif (strChoice == '4'):
                # 5a Show the current items in the table
                x.DisplayList()
                # 5b Ask if they want save that data
                if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
                    x.SaveFile()
                    input("Data saved to file! Press the [Enter] key to return to menu.")
                else:
                    input(
                        "New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
                continue  # to show the menu
            elif (strChoice == '5'):
                break  # and Exit the program


# Call the ToDo class and the LoadFile and Main functions
x = ToDo()
x.LoadFile()
x.Main()